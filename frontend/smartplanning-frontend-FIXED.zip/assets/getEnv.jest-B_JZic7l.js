function n(t,e){return e??""}export{n as default,n as getEnvVar};
